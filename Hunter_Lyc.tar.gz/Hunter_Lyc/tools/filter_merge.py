import numpy as np
import pickle
from collections import Counter
import os
import random
import argparse

def filter_by_thresholds(data, class_thresholds):
    """
    根据全局阈值筛选单帧检测结果
    """
    pred_labels = data['pred_labels']
    scores = data['score']
    keep_mask = np.ones(len(scores), dtype=bool)

    for cls_id, thr in class_thresholds.items():
        cls_mask = (pred_labels == cls_id)
        if thr > -1:
            keep_mask &= ~(cls_mask & (scores < thr))
    
    new_data = {
        'name': data['name'][keep_mask],
        'pred_labels': pred_labels[keep_mask],
        'score': scores[keep_mask],
        'boxes_lidar': data['boxes_lidar'][keep_mask],
        'platform': data['platform'],
        'frame_id': data['frame_id']
    }
    return new_data

def keep_only_class_list(data_list, keep_cls=1):
    """
    在一个 list[dict] 中，每帧只保留指定类别
    """
    new_list = []
    for data in data_list:
        pred_labels = data['pred_labels']
        keep_mask = (pred_labels == keep_cls)

        new_data = {
            'name': data['name'][keep_mask],
            'pred_labels': data['pred_labels'][keep_mask],
            'score': data['score'][keep_mask],
            'boxes_lidar': data['boxes_lidar'][keep_mask],
            'platform': data['platform'],
            'frame_id': data['frame_id']
        }
        new_list.append(new_data)
    return new_list

def merge_data_list(data_list1, data_list2):
    merged_list = []
    for d1, d2 in zip(data_list1, data_list2):
        merged_item = {
            'pred_labels': np.concatenate([d1['pred_labels'], d2['pred_labels']]),
            'score': np.concatenate([d1['score'], d2['score']]),
            'boxes_lidar': np.concatenate([d1['boxes_lidar'], d2['boxes_lidar']], axis=0),
            'name': np.concatenate([d1['name'], d2['name']]),
            'platform': d1.get('platform', d2.get('platform')),
            'frame_id': d1.get('frame_id', d2.get('frame_id'))
        }
        merged_list.append(merged_item)
    return merged_list
    
def filter_class(input_pkl,class_thresholds):
    with open(input_pkl, "rb") as f:
        data_list = pickle.load(f)
    # 逐帧筛选
    new_list = []
    for data in data_list:
        new_data = filter_by_thresholds(data, class_thresholds)
        new_list.append(new_data)
    return new_list


def show_pkl(input_pkl):
    print(f"Showing results for {input_pkl}")
    with open(input_pkl, "rb") as f:
        data_list = pickle.load(f)

    all_labels = np.hstack([f["pred_labels"] for f in data_list])
    label_count = Counter(all_labels)
    # print(data_list[0])
    # 打印结果

    for k, v in label_count.items():
        name = "Car" if k == 1 else "Pedestrian"
        print(f"{name} (label={k}) 数量: {v}")
    sum=0
    for k, v in label_count.items():
        sum+=v
    print(f"总数量: {sum/len(data_list)}")
    # # 用字典存储类别到分数的映射
    # cls_scores = {}

    # for frame in data_list:
    #     labels = frame['pred_labels']
    #     scores = frame['score']
    #     names = frame['name']

    #     for lbl, name, score in zip(labels, names, scores):
    #         if lbl not in cls_scores:
    #             cls_scores[lbl] = []
    #         cls_scores[lbl].append(score)

    # # 打印每个类别的最低分数
    # for lbl, scores in cls_scores.items():
    #     min_score = float(np.min(scores))
    #     print(f"类别 {lbl} ({data_list[0]['name'][0] if lbl==1 else 'Pedestrian'}) 最低分数: {min_score:.6f}")

def process_pkl(car_pkl,prdestrian_pkl, output_pkl, class_thresholds):
    # show_pkl(car_pkl)
    # show_pkl(prdestrian_pkl)
    data1=filter_class(car_pkl,class_thresholds)
    data2=filter_class(prdestrian_pkl,class_thresholds)

    data1 = keep_only_class_list(data1,1)   
    data2 = keep_only_class_list(data2,2)

    new_list = merge_data_list(data1, data2)
    dir_path = os.path.dirname(output_pkl)
    # 如果路径不存在，则创建
    os.makedirs(dir_path, exist_ok=True)
    # 1. 先算全局阈值
    with open(output_pkl, "wb") as f:
        pickle.dump(new_list, f)
    print(f"处理完成，结果保存到 {output_pkl}")
    show_pkl(output_pkl)

def main():
    parser = argparse.ArgumentParser(
        description=f"merge two pkl."
    )
    parser.add_argument("--car_pkl", default="../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_d/default/eval/epoch_3/val/default/result.pkl", help="Local directory to  use car class pkl")
    parser.add_argument("--prdestrian_pkl", default="../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det/default/eval/epoch_3/val/default/result.pkl", help="Local directory to use prdestrian class pkl")
    parser.add_argument("--car_score", default=0.3058, type=float, help="car score threshold")
    parser.add_argument("--prdestrian_score", default=0.0920, type=float, help="prdestrian score threshold")
    parser.add_argument("--output_pkl", default="../output/result_default/result.pkl", help="Local directory to save the result")
    args = parser.parse_args()

    process_pkl(car_pkl=args.car_pkl,
    prdestrian_pkl=args.prdestrian_pkl,
    output_pkl=args.output_pkl, 
    class_thresholds={1: args.car_score, 2: args.prdestrian_score})

if __name__ == "__main__":
    main()