#!/bin/bash

NUM_GPUs=${1:-1}      # 第一个参数 预测GPU数量，默认 1
BATCH_SIZE=${2:-16}   # 第二个参数 预测BATCH_SIZE数量，默认16

CFG_FILE=./cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_car_st3d.yaml
CKPT=../ckpt/phase1_drone_16.pth
./pi3det_test.sh ${NUM_GPUs} ${BATCH_SIZE} ${CFG_FILE} ${CKPT}

#out to ../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_car_st3d/default/eval/epoch_16/val/default/result.pkl

car_pkl="../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_car_st3d/default/eval/epoch_16/val/default/result.pkl"
output_pkl="../output/phase1_drone/result.pkl"

mkdir -p "$(dirname "$output_pkl")"
cp ${car_pkl} ${output_pkl}
