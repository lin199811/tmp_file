#!/bin/bash

mkdir ../ckpt
huggingface-cli download LinYC2024/track5_model --local-dir ../ckpt/  --repo-type=model