#!/bin/bash

NUM_GPUs=${1:-1}      # 第一个参数 预测GPU数量，默认 1
BATCH_SIZE=${2:-16}   # 第二个参数 预测BATCH_SIZE数量，默认16

CFG_FILE=./cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_d.yaml
CKPT=../ckpt/phase2_quadruped_16_mos.pth
./pi3det_test.sh ${NUM_GPUs} ${BATCH_SIZE} ${CFG_FILE} ${CKPT}

#out to ../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_d/default/eval/epoch_16/val/default/result.pkl


CFG_FILE=./cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d.yaml
CKPT=../ckpt/phase2_quadruped_16.pth
./pi3det_test.sh ${NUM_GPUs} ${BATCH_SIZE} ${CFG_FILE} ${CKPT}

#out to ../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d/default/eval/epoch_16/val/default/result.pkl

car_pkl="../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_d/default/eval/epoch_16/val/default/result.pkl"
prdestrian_pkl="../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d/default/eval/epoch_16/val/default/result.pkl"
car_score=0.3058 #0.3058
prdestrian_score=0.09 #0.10105

output_pkl="../output/phase2_quadruped/result.pkl"

python filter_merge.py --car_pkl ${car_pkl} --prdestrian_pkl ${prdestrian_pkl} \
                    --car_score ${car_score} --prdestrian_score ${prdestrian_score} \
                    --output_pkl ${output_pkl}
