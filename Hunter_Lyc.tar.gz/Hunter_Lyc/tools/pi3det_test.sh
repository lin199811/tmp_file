#!/bin/bash

NUM_GPUs=${1:-1}
BATCH_SIZE=${2:-16}
CFG_FILE=${3:-./cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_d.yaml}
CKPT=${4:-../ckpt/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mod.pth}

# ----------------------
# 运行逻辑
# ----------------------

if [ -n "${CKPT}" ]; then
    CKPT_ARG="--ckpt ${CKPT}"
else
    CKPT_ARG="--eval_all"
fi

if [ ${NUM_GPUs} -gt 1 ]; then
    echo "Running with ${NUM_GPUs} GPUs..."
    bash scripts/dist_test.sh ${NUM_GPUs} \
        --cfg_file ${CFG_FILE} \
        --batch_size ${BATCH_SIZE} \
        ${CKPT_ARG}
else
    echo "Running with single GPU..."
    python test.py \
        --cfg_file ${CFG_FILE} \
        --batch_size ${BATCH_SIZE} \
        ${CKPT_ARG}
fi