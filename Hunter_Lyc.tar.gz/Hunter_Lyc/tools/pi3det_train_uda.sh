#!/bin/bash

NUM_GPUs=${1:-2}

CFG_FILE=./cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_8u.yaml


PRETRAINED_MODEL=../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_back/default/ckpt/checkpoint_epoch_30.pth

# PRETRAINED_MODEL=../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_0.1_26e/default/ckpt/checkpoint_epoch_26.pth

# CFG_FILE=./cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_d.yaml


# CFG_FILE=./cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_pedestrian_st3d.yaml
# PRETRAINED_MODEL=../output/cfgs/pi3det_gblobs/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_pedestrian/default/ckpt/checkpoint_epoch_26.pth

if [ -n "${PRETRAINED_MODEL}" ]; then
    CKPT_ARG="--pretrained_model ${PRETRAINED_MODEL}"
else
    CKPT_ARG=" "
fi

if [ ${NUM_GPUs} -gt 1 ]; then
    echo "Running with ${NUM_GPUs} GPUs..."
    bash scripts/dist_train_uda.sh ${NUM_GPUs} \
        --cfg_file ${CFG_FILE} \
         ${CKPT_ARG}
else
    echo "Running with single GPU..."
    python train_uda.py \
        --cfg_file ${CFG_FILE} \
         ${CKPT_ARG}
fi