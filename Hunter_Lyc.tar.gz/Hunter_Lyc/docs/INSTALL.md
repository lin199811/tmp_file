# Installation

### Requirements
All the codes are tested in the following environment:
* Rocky Linux 8.10 (Green Obsidian)。
* Python 3.8
* PyTorch 2.1.0
* CUDA 11.8
* spconv-cu11.8(spconv-cu118==2.3.6)


### Install codebase

```sh
conda create -n track5 python=3.8 -y
conda activate track5
pip install torch==2.1.0 torchvision==0.16.0 torchaudio==2.1.0 --index-url https://download.pytorch.org/whl/cu118
pip install spconv-cu118 -i https://pypi.tuna.tsinghua.edu.cn/simple
git clone https://github.com/
pip install -r requirements.txt
pip install typing_extensions==4.10.0 numpy==1.23.5 av2==0.2.0 #需要更新
#cd Project dir
pip install -e .
# **Mmaba**
cd pcdet/ops/mamba
python setup.py install
cd ../../../tools/
```