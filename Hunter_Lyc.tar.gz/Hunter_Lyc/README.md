## Installation

Please refer to [INSTALL.md](docs/INSTALL.md) for the installation of LION codebase.

## Getting Started

### Data Preparation

The Track 5 dataset follows the KITTI format. Each sample consists of:

- A front-view RGB image
- A LiDAR point cloud covering the camera’s field of view
- Calibration parameters
- 3D bounding-box annotations (for training)
  > Calibration and annotations are packaged together in `.pkl` files.

We use the **same training set** (vehicle platform) for both phases, but **different validation sets**. The full dataset is hosted on Hugging Face:

[robosense/track5-cross-platform-3d-object-detection](https://huggingface.co/datasets/robosense/datasets/tree/main/track5-cross-platform-3d-object-detection)

1. **Download the dataset**
   ```bash
   # export your huggingface token: hf_xxx
   export HUGGINGFACE_TOKEN=${TOKEN}
   python tools/load_dataset.py $USER_DEFINE_OUTPUT_PATH
   ```
2. **Link data into the project**

   ```bash
    # Create target directory
    mkdir -p data/pi3det

    # Link the training split
    ln -s $USER_DEFINE_OUTPUT_PATH/track5-cross-platform-3d-object-detection/phase12_vehicle_training/training \
        data/pi3det/training

    # Link the validation split for Phase N (Drone or Quadruped)
    ln -s $USER_DEFINE_OUTPUT_PATH/track5-cross-platform-3d-object-detection/phase{$N}_{$PLATFORM}_validation/validation \
        data/pi3det/validation

    # Link the .pkl info files
    ln -s $USER_DEFINE_OUTPUT_PATH/track5-cross-platform-3d-object-detection/phase12_vehicle_training/training/pi3det_infos_train.pkl \
        data/pi3det/pi3det_infos_train.pkl
    ln -s $USER_DEFINE_OUTPUT_PATH/track5-cross-platform-3d-object-detection/phase{$N}_{$PLATFORM}_validation/pi3det_infos_val.pkl \
        data/pi3det/pi3det_infos_val.pkl
   ```

3. **Verify your directory structure**  
   After linking, your `data/` folder should look like this:
   ````bash
    data/
    └── pi3det/
        ├── training/
        │   ├── image/
        │   │   ├── 0000000.jpg
        │   │   └── 0000001.jpg
        │   └── point_cloud/
        │       ├── 0000000.bin
        │       └── 0000001.bin
        ├── validation/
        │   ├── image/
        │   │   ├── 0000000.jpg
        │   │   └── 0000001.jpg
        │   └── point_cloud/
        │       ├── 0000000.bin
        │       └── 0000001.bin
        ├── pi3det_infos_train.pkl
        └── pi3det_infos_val.pkl
    ```
   ````

### Evaluating the Model

please refer to [tools/](tools/)

1. **download all model checkpiont**

```shell script
# cd Project_dit/tools
bash down_load_model.sh
```
2. **Verify your directory structure**  
   After download, your `ckpt/` folder should look like this:
   ````bash
    ckpt/
    ├── phase1_drone_16.pth
    ├── phase2_quadruped_16.pth
    └── phase2_quadruped_16_mos.pth

    ```
3 **test all result**
 * Before testing Phase 1, make sure that `data/pi3det` is a symbolic link to the **Phase 1 (Drone) dataset**.
```shell script
# cd Project_dit/tools
# NUM_GPUs=${1:-1}      # 第一个参数 预测GPU数量，默认 1
# BATCH_SIZE=${2:-16}   # 第二个参数 预测BATCH_SIZE数量，默认16
bash test_phase1_drone.sh 1 16 # 一卡推理，用16 batch_size,显存占用约为25G
```
 * Before testing Phase 2, make sure that `data/pi3det` is a symbolic link to the **Phase 2(Quadruped) dataset**.
```shell script
# cd Project_dit/tools
# NUM_GPUs=${1:-1}      # 第一个参数 预测GPU数量，默认 1
# BATCH_SIZE=${2:-16}   # 第二个参数 预测BATCH_SIZE数量，默认16
bash test_phase2_quadruped.sh 1 16 # 一卡推理，用16 batch_size,显存占用约为25G
```

We have generated
- Phase 1 results: `output/phase1_drone/result.pkl`
- Phase 2 results: `output/phase2_quadruped/result.pkl`
