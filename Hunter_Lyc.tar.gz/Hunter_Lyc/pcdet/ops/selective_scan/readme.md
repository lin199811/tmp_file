### install selective_scan_cuda_core; selective_scan
```bash
rm -r dist/ build/; pip install .
pytest test_selective_scan.py # expected all pass
```

