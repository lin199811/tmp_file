import numpy as np
import pickle
from collections import Counter
import os
import random
def compute_class_thresholds(data_list, class_max_keep):
    """
    统计整个 pkl 的所有检测结果，计算每个类别的全局分数阈值
    """
    thresholds = {}
    all_scores = {}

    # 收集每个类别的所有分数
    for data in data_list:
        pred_labels = data['pred_labels']
        scores = data['score']
        for cls_id in np.unique(pred_labels):
            cls_scores = scores[pred_labels == cls_id]
            all_scores.setdefault(cls_id, []).extend(cls_scores.tolist())
    
    # 计算阈值
    for cls_id, scores in all_scores.items():
        scores = np.array(scores)
        max_keep = class_max_keep.get(cls_id, len(scores))  # 没限制就保留全部
        if len(scores) <= max_keep:
            thresholds[cls_id] = -1.0  # 全保留
        else:
            sorted_scores = np.sort(scores)[::-1]  # 从大到小
            thresholds[cls_id] = sorted_scores[max_keep - 1]  # 第 max_keep 个的分数
    
    return thresholds


def filter_by_thresholds(data, thresholds):
    """
    根据全局阈值筛选单帧检测结果
    """
    pred_labels = data['pred_labels']
    scores = data['score']
    keep_mask = np.ones(len(scores), dtype=bool)

    for cls_id, thr in thresholds.items():
        cls_mask = (pred_labels == cls_id)
        if thr > -1:
            keep_mask &= ~(cls_mask & (scores < thr))
    
    new_data = {
        'name': data['name'][keep_mask],
        'pred_labels': pred_labels[keep_mask],
        'score': scores[keep_mask],
        'boxes_lidar': data['boxes_lidar'][keep_mask],
        'platform': data['platform'],
        'frame_id': data['frame_id']
    }
    return new_data

def keep_only_class_list(data_list, keep_cls=1):
    """
    在一个 list[dict] 中，每帧只保留指定类别
    """
    new_list = []
    for data in data_list:
        pred_labels = data['pred_labels']
        keep_mask = (pred_labels == keep_cls)

        new_data = {
            'name': data['name'][keep_mask],
            'pred_labels': data['pred_labels'][keep_mask],
            'score': data['score'][keep_mask],
            'boxes_lidar': data['boxes_lidar'][keep_mask],
            'platform': data['platform'],
            'frame_id': data['frame_id']
        }
        new_list.append(new_data)
    return new_list

def merge_data_list(data_list1, data_list2):
    merged_list = []
    for d1, d2 in zip(data_list1, data_list2):
        merged_item = {
            'pred_labels': np.concatenate([d1['pred_labels'], d2['pred_labels']]),
            'score': np.concatenate([d1['score'], d2['score']]),
            'boxes_lidar': np.concatenate([d1['boxes_lidar'], d2['boxes_lidar']], axis=0),
            'name': np.concatenate([d1['name'], d2['name']]),
            'platform': d1.get('platform', d2.get('platform')),
            'frame_id': d1.get('frame_id', d2.get('frame_id'))
        }
        merged_list.append(merged_item)
    return merged_list
def filter_class(input_pkl,class_max_keep):
    with open(input_pkl, "rb") as f:
        data_list = pickle.load(f)

    # all_labels = np.hstack([f["pred_labels"] for f in data_list])
    # label_count = Counter(all_labels)
    # # print(data_list[0])
    # # 打印结果
    # for k, v in label_count.items():
    #     name = "Car" if k == 1 else "Pedestrian"
    #     print(f"{name} (label={k}) 数量: {v}")
    # 1. 先算全局阈值
    # thresholds = compute_class_thresholds(data_list, class_max_keep)
    thresholds = {1: 0.305805, 2: 1.0}
    print("全局阈值:", thresholds)

    # 2. 再逐帧筛选
    new_list = []
    for data in data_list:
        new_data = filter_by_thresholds(data, thresholds)
        new_list.append(new_data)
    all_labels = np.hstack([f["pred_labels"] for f in new_list])
    label_count = Counter(all_labels)
    # print(new_list[0])

    # 打印结果
    for k, v in label_count.items():
        name = "Car" if k == 1 else "Pedestrian"
        print(f"{name} (label={k}) 数量: {v}")
    return new_list

def process_pkl(input_pkl,input_pkl2, output_pkl, class_max_keep):
    data1=filter_class(input_pkl,class_max_keep)
    data2=filter_class(input_pkl2,class_max_keep)

    data1 = keep_only_class_list(data1,1)   
    data2 = keep_only_class_list(data2,2)

    new_list = merge_data_list(data1, data2)

    # 1. 先算全局阈值
    with open(output_pkl, "wb") as f:
        pickle.dump(new_list, f)

    print(f"处理完成，结果保存到 {output_pkl}")

def process_all_results(root_dir, class_max_keep):
    for dirpath, _, filenames in os.walk(root_dir):
        if "result.pkl" in filenames:
            pkl_path = os.path.join(dirpath, "result.pkl")
            class_max_keep_tmp = {1: 9487, 2: 28045}
            # # 遍历字典并加上随机数
            # for k in class_max_keep_tmp:
            #     class_max_keep_tmp[k] += random.randint(0, 300)  # 小于1000的随机整数
            process_pkl(pkl_path.replace('eval_mos_d2', 'eval_mos_d'), pkl_path, pkl_path.replace('eval_mos_d2', 'eval'), class_max_keep_tmp)


if __name__ == "__main__":
    root_dir = "/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det/default/eval_mos_d2"

    # 类别限制（示例：Car=3000，Pedestrian=2000，可改成你的需求）
    class_limit = {1: 9300, 2: 28000}

    process_all_results(root_dir, class_limit)