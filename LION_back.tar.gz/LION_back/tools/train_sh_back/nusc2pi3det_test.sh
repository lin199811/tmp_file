#!/bin/bash

NUM_GPUs=${1:-2}

PLATFORM=quadruped
N=2

CFG_FILE=./cfgs/DA/phase${N}_vehicle_${PLATFORM}/source_only/pvrcnn_st3d.yaml

CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det.yaml
CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det/default/ckpt/checkpoint_epoch_26.pth

CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_car.yaml
CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_car/default/ckpt/checkpoint_epoch_26.pth
CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_car_st3d/default/ckpt/checkpoint_epoch_16.pth
CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_car_st3d.yaml

# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_0.1_32e/default/ckpt/checkpoint_epoch_32.pth
# CKPT=/home/uqhyan14/vlm_challenge/LION/ckpt/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs/checkpoint_epoch_30.pth
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det/default/ckpt/checkpoint_epoch_30.pth
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40/default/ckpt/checkpoint_epoch_30.pth


# CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d.yaml
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_d/default/ckpt/checkpoint_epoch_20.pth
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_d/default/ckpt/checkpoint_epoch_16.pth
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_d-1/default/ckpt/checkpoint_epoch_15.pth

# # CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40/default/ckpt/checkpoint_epoch_30.pth



# CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l405f.yaml
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l405f/default/ckpt/checkpoint_epoch_32.pth

# CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40.yaml
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40/default/ckpt/checkpoint_epoch_36.pth


# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_1/default/ckpt/checkpoint_iter_2100.pth
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_2/default/ckpt/checkpoint_iter_672.pth
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_d/default/ckpt/checkpoint_iter_2800.pth


# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_mos_d2/default/ckpt/checkpoint_iter_448.pth

CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d.yaml
CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d/default/ckpt/checkpoint_epoch_16.pth

CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_car_st3d.yaml
CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_l40_car/default/ckpt/checkpoint_epoch_26.pth

# CFG_FILE=./cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_8u.yaml
# CKPT=/home/uqhyan14/vlm_challenge/LION/output/cfgs/nuscenes-kitti_models/voxel_rcnn_with_centerhead_gblobs_pi3det_st3d_8u/default/ckpt/checkpoint_epoch_8.pth
# ----------------------
# 运行逻辑
# ----------------------

if [ -n "${CKPT}" ]; then
    CKPT_ARG="--ckpt ${CKPT}"
else
    CKPT_ARG="--eval_all"
fi

if [ ${NUM_GPUs} -gt 1 ]; then
    echo "Running with ${NUM_GPUs} GPUs..."
    bash scripts/dist_test.sh ${NUM_GPUs} \
        --cfg_file ${CFG_FILE} \
        --batch_size 16 \
        ${CKPT_ARG}
else
    echo "Running with single GPU..."
    python test.py \
        --cfg_file ${CFG_FILE} \
        --batch_size 16 \
        ${CKPT_ARG}
fi