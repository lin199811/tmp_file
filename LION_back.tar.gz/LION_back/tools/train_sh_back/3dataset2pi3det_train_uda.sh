#!/bin/bash

NUM_GPUs=${1:-2}

CFG_FILE=./cfgs/kitti-waymo_models/second_gblobs_3d-vfield_pi3det_st3d.yaml
PRETRAINED_MODEL=/home/uqhyan14/vlm_challenge/LION/output/cfgs/kitti-waymo_models/second_gblobs_3d-vfield_pi3det/default/ckpt/checkpoint_epoch_80.pth


if [ -n "${PRETRAINED_MODEL}" ]; then
    CKPT_ARG="--pretrained_model ${PRETRAINED_MODEL}"
else
    CKPT_ARG=" "
fi

if [ ${NUM_GPUs} -gt 1 ]; then
    echo "Running with ${NUM_GPUs} GPUs..."
    bash scripts/dist_train_uda.sh ${NUM_GPUs} \
        --cfg_file ${CFG_FILE} \
         ${CKPT_ARG}
else
    echo "Running with single GPU..."
    python train_uda.py \
        --cfg_file ${CFG_FILE} \
         ${CKPT_ARG}
fi